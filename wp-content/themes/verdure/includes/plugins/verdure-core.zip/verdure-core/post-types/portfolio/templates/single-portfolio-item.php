<?php

get_header();

verdure_mikado_get_title();

do_action('verdure_mikado_before_main_content');

verdure_core_get_single_portfolio();

get_footer();