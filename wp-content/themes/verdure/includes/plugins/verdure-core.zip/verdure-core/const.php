<?php

define( 'VERDURE_CORE_VERSION', '1.0' );
define( 'VERDURE_CORE_ABS_PATH', dirname( __FILE__ ) );
define( 'VERDURE_CORE_REL_PATH', dirname( plugin_basename( __FILE__ ) ) );
define( 'VERDURE_CORE_URL_PATH', plugin_dir_url( __FILE__ ) );
define( 'VERDURE_CORE_ASSETS_PATH', VERDURE_CORE_ABS_PATH . '/assets' );
define( 'VERDURE_CORE_ASSETS_URL_PATH', VERDURE_CORE_URL_PATH . 'assets' );
define( 'VERDURE_CORE_CPT_PATH', VERDURE_CORE_ABS_PATH . '/post-types' );
define( 'VERDURE_CORE_CPT_URL_PATH', VERDURE_CORE_URL_PATH . 'post-types' );
define( 'VERDURE_CORE_SHORTCODES_PATH', VERDURE_CORE_ABS_PATH . '/shortcodes' );
define( 'VERDURE_CORE_SHORTCODES_URL_PATH', VERDURE_CORE_URL_PATH . 'shortcodes' );