<div class="mkdf-uncovering-sections">
	<ul class="mkdf-us-wrapper curtains" data-image-holder-name=".mkdf-uss-image-holder" data-fade-element-name=".mkdf-fss-shadow">
		<?php echo do_shortcode($content); ?>
	</ul>
    <div class="mkdf-fss-shadow"></div>
</div>