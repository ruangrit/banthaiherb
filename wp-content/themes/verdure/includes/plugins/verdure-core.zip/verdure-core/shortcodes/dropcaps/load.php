<?php

include_once VERDURE_CORE_SHORTCODES_PATH . '/dropcaps/functions.php';
include_once VERDURE_CORE_SHORTCODES_PATH . '/dropcaps/dropcaps.php';