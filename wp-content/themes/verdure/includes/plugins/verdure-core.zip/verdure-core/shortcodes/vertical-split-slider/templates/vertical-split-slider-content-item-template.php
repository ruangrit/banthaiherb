<div class="mkdf-vss-ms-section" <?php echo verdure_mikado_get_inline_attrs($content_data); ?> <?php verdure_mikado_inline_style($content_style);?>>
	<?php echo do_shortcode($content); ?>
</div>