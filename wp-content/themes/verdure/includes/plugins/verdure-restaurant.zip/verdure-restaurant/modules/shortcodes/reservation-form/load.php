<?php

include_once VERDURE_RESTAURANT_SHORTCODES_PATH.'/reservation-form/functions.php';
include_once VERDURE_RESTAURANT_SHORTCODES_PATH.'/reservation-form/reservation-form.php';